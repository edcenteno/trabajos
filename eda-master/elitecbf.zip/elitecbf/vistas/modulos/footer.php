<footer class="footer">
	<div class="pull-right hidden-xs">
      
    </div>
    <strong>Copyright &copy; 2018 ARHU INTERNACIONAL.</strong>

	Todos los derechos reservados. <b>Version</b> 2.2.0 

</footer>