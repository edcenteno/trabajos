<?php
	require_once("./autoload.php");
	
	$test = new Reniec\Reniec();
	
	var_dump( $test->search("44274795") );
?>
