<div class="card-footer text-muted">
	Copyright © 2018 ARHU INTERNACIONAL. Todos los derechos reservados. Version 1.6.5
</div>