

<!-- <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="js/alertifyjs/css/themes/default.css">
<link rel="stylesheet" type="text/css" href="js/alertifyjs/css/alertify.css">

<script src="js/jquery-3.2.1.min.js"></script>
 -->

<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="librerias/dt/datatables.min.css"/>
 


<link rel="stylesheet" type="text/css" href="librerias/bootstrap/bootstrap.min.css">
<!-- <link rel="stylesheet" type="text/css" href="librerias/datatable/bootstrap.css">
<link rel="stylesheet" type="text/css" href="librerias/datatable/dataTables.bootstrap4.min.css"> -->
<link rel="stylesheet" type="text/css" href="librerias/alertify/css/alertify.css">
<link rel="stylesheet" type="text/css" href="librerias/alertify/css/themes/bootstrap.css">
<link rel="stylesheet" type="text/css" href="js/alertifyjs/css/themes/default.css">
<link rel="stylesheet" type="text/css" href="js/alertifyjs/css/alertify.css">

<link rel="stylesheet" type="text/css" href="librerias/fontawesome/css/font-awesome.css">

<!-- <link rel="stylesheet" href="librerias/datatablesres/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="librerias/datatablesres/css/responsive.bootstrap.min.css"> -->
<!-- <link rel="stylesheet" type="text/css" href="librerias/datatables/datatables.css">
 

<script type="text/javascript" charset="utf8" src="librerias/datatables/datatables.js"></script> -->
<script src="librerias/jquery.min.js"></script>
<script src="librerias/bootstrap/popper.min.js"></script>
<script src="librerias/bootstrap/bootstrap.min.js"></script>
<!-- <script src="librerias/datatable/jquery.dataTables.min.js"></script>
<script src="librerias/datatable/dataTables.bootstrap4.min.js"></script> -->
<script src="librerias/alertify/alertify.js"></script>
<script type="text/javascript" src="librerias/dt/datatables.min.js"></script>
<!-- <script src="librerias/datatablesres/js/dataTables.bootstrap.min.js"></script>
<script src="librerias/datatablesres/js/dataTables.responsive.min.js"></script>
<script src="librerias/datatablesres/js/responsive.bootstrap.min.js"></script> -->



<link rel="shortcut icon" href="img/favicon.ico" type="image/ico" />
<title>ARHU Internacional</title>
<meta name="viewport" content="width=device-width, initial-scale=1">